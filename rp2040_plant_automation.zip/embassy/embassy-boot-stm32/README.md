# embassy-boot-stm32

An [Embassy](https://embassy.dev) project.

An adaptation of `embassy-boot` for STM32.

## Features

* Configure bootloader partitions based on linker script.
* Load applications from active partition.
