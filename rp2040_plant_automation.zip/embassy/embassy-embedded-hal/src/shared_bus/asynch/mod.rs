//! Asynchronous shared bus implementations for embedded-hal-async
pub mod i2c;
pub mod spi;
