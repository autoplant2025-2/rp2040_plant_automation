//! Blocking shared bus implementations for embedded-hal
pub mod i2c;
pub mod spi;
