# `embassy-net` integration for Linux TUN/TAP interfaces.

[`embassy-net`](https://crates.io/crates/embassy-net) integration for for Linux TUN (IP medium) and TAP (Ethernet medium) interfaces.

## Interoperability

This crate can run on any executor.
