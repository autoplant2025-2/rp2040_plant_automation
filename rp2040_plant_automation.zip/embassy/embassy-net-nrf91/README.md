# nRF91 `embassy-net` integration

[`embassy-net`](https://crates.io/crates/embassy-net) driver for Nordic nRF91-series cellular modems.

See the [`examples`](https://github.com/embassy-rs/embassy/tree/main/examples/nrf9160) directory for usage examples with the nRF9160.

## Interoperability

This crate can run on any executor.
