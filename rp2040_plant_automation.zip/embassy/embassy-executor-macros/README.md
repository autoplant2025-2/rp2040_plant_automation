# embassy-executor-macros

An [Embassy](https://embassy.dev) project.

NOTE: Do not use this crate directly. The macros are re-exported by `embassy-executor`.
