mod asynch;
mod blocking;

pub(crate) use asynch::AsyncTestFlash;
pub(crate) use blocking::BlockingTestFlash;
