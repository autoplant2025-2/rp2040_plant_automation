# `embassy-net-ppp`

[`embassy-net`](https://crates.io/crates/embassy-net) integration for PPP over Serial.

## Interoperability

This crate can run on any executor.

It supports any serial port implementing [`embedded-io-async`](https://crates.io/crates/embedded-io-async).
